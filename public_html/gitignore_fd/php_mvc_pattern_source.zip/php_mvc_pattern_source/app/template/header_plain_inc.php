<!DOCTYPE html>
<html lang="us">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title><?php echo PORTAL_NAME ?></title>

		<meta http-equiv="expires" content="0">
		<meta http-equiv="pragma" content="no-cache">
		<meta http-equiv="cache-control" content="no-cache">

		<link href="/css/stylesheet.css" rel="stylesheet">
		<link href="/css/default.css" rel="stylesheet">
		<link href="/css/dialog.css" rel="stylesheet">
		<link href="/css/jquery-ui.css" rel="stylesheet">


		<script language="javascript" type="text/javascript" src="/js/jquery.js.download"></script>
		<script language="javascript" type="text/javascript" src="/js/axios.min.js.download"></script>
		<script language="javascript" type="text/javascript" src="/js/vue.js.download"></script>
		<script language="javascript" type="text/javascript" src="/js/jquery-ui.js.download"></script>
	</head>
	<body>

