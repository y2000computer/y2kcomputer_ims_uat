<!DOCTYPE html>
<html lang="en">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BloomPon Portal</title>
    <link rel="stylesheet" href="/assets/css/app.css">
    <script src="/assets/js/javascript.js"></script>
</head>

