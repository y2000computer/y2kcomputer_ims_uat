	<footer>
		<div class="container">
			<div class="text-right">
				Copyright © Y2K Computer Co.<br/> 
				All rights reserved
			</div>
		</div>
	</footer></body>
</html>
