<!DOCTYPE html>
<html lang="us">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title><?php echo PORTAL_NAME ?></title>

		<meta http-equiv="expires" content="0">
		<meta http-equiv="pragma" content="no-cache">
		<meta http-equiv="cache-control" content="no-cache">

		<link href="/css/report.css" rel="stylesheet">


	</head>
	<body>
