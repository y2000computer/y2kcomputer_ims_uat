<!doctype html>
<html lang="us">
<head>
<title>ERP - HKBER LIMITED</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta http-equiv="expires" content="0" /> 
<meta http-equiv="pragma" content="no-cache" /> 
<meta http-equiv="cache-control" content="no-cache" /> 

<link href="/css/stylesheet.css" rel="stylesheet" /> 
<link href="/css/default.css" rel="stylesheet" />
<link href="/css/dialog.css" rel="stylesheet" />        

	
</head>
<body>
<br>
<UL>
Warning! You have no right to access this module.<br>
Please contact to system support
</br>
</body>
</html>

<?php die();?>