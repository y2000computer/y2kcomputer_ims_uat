<?php
echo 'Menu';
echo ' &raquo; ';
echo '<a href="/'.IS_PORTAL.'/'.IS_LANG.'/photo_home/">Photo Library</a>';
echo ' &raquo; ';
echo '<a href="/'.IS_PORTAL.'/'.IS_LANG.'/photo_entry/">Photo Entry</a>';
echo ' &raquo; ';
?>