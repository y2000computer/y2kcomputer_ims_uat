<?php
echo 'Menu';
echo ' &raquo; ';
echo '<a href="/'.IS_PORTAL.'/'.IS_LANG.'/gl_home/">General Ledger</a>';
echo ' &raquo; ';
echo '<a href="/'.IS_PORTAL.'/'.IS_LANG.'/gl_report_trial_balance/">Inquiries and Reports  - Trial Balance</a>';
echo ' &raquo; ';
?>