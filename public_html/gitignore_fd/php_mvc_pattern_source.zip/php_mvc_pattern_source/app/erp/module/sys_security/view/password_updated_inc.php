<?php
require __DIR__.'/../../../../template/header_inc.php';
require __DIR__.'/../../../../function/check_session_func.php';
?>
<link href="/css/changepassword.css" rel="stylesheet">

		<div class="bodyContent" id="BodyDiv">
			<div class="contentWrapper" id="BodyWrapDiv">
				<div class="cardWrapper" id="FullContetnDiv">
					<div class="pageTitle">Change password</div>
					<span class="alertMsg successMsg">Update Password successfully.</span>
				</div>
			</div>
		</div>
		

<?php
require __DIR__.'/../../../../template/footer_inc.php';
?>
		
