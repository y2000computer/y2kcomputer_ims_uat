<?php
echo 'Menu';
echo ' &raquo; ';
echo '<a href="/'.IS_PORTAL.'/'.IS_LANG.'/gl_home/">General Ledger</a>';
echo ' &raquo; ';
echo '<a href="/'.IS_PORTAL.'/'.IS_LANG.'/gl_year_end/">Maintenance  - Year End</a>';
echo ' &raquo; ';
?>