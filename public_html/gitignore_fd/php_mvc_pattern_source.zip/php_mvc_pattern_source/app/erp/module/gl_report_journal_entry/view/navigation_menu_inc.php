<?php
echo 'Menu';
echo ' &raquo; ';
echo '<a href="/'.IS_PORTAL.'/'.IS_LANG.'/gl_home/">General Ledger</a>';
echo ' &raquo; ';
echo '<a href="/'.IS_PORTAL.'/'.IS_LANG.'/gl_report_journal_entry/">Inquiries and Reports  - Journal Entry</a>';
echo ' &raquo; ';
?>