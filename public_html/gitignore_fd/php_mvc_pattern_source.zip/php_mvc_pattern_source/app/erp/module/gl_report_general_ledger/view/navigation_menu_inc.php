<?php
echo 'Menu';
echo ' &raquo; ';
echo '<a href="/'.IS_PORTAL.'/'.IS_LANG.'/gl_home/">General Ledger</a>';
echo ' &raquo; ';
echo '<a href="/'.IS_PORTAL.'/'.IS_LANG.'/gl_report_general_ledger/">Inquiries and Reports  - General Ledger</a>';
echo ' &raquo; ';
?>