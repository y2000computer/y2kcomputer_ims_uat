<?php
echo 'Menu';
echo ' &raquo; ';
echo '<a href="/'.IS_PORTAL.'/'.IS_LANG.'/prop_home/">Properly Rent/Maint.</a>';
echo ' &raquo; ';
echo '<a href="/'.IS_PORTAL.'/'.IS_LANG.'/prop_mainten_rent_inv_generation/">Maintenance  - Rent Invoice Generation</a>';
echo ' &raquo; ';
?>