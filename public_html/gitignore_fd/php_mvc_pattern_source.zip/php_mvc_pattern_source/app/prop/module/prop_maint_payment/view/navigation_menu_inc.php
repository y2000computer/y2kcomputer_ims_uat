<?php
echo 'Menu';
echo ' &raquo; ';
echo '<a href="/'.IS_PORTAL.'/'.IS_LANG.'/prop_home/">Properly Rent/Maint.</a>';
echo ' &raquo; ';
echo '<a href="/'.IS_PORTAL.'/'.IS_LANG.'/prop_maint_payment/">Transaction - Maint. Payment</a>';
echo ' &raquo; ';
?>