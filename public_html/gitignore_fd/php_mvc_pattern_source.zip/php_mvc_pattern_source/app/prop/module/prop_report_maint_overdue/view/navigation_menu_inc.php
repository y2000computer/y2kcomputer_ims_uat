<?php
echo 'Menu';
echo ' &raquo; ';
echo '<a href="/'.IS_PORTAL.'/'.IS_LANG.'/prop_home/">Properly Rent/Maint.</a>';
echo ' &raquo; ';
echo '<a href="/'.IS_PORTAL.'/'.IS_LANG.'/prop_report_maint_overdue/">Inquiries and Reports  - Maint. Overdue Report</a>';
echo ' &raquo; ';
?>