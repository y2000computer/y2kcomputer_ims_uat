<?php
echo 'Menu';
echo ' &raquo; ';
echo '<a href="/'.IS_PORTAL.'/'.IS_LANG.'/prop_home/">Properly Rent/Maint.</a>';
echo ' &raquo; ';
echo '<a href="/'.IS_PORTAL.'/'.IS_LANG.'/prop_report_tenant_info/">Inquiries and Reports  - Tenant Information Report</a>';
echo ' &raquo; ';
?>