<?php
echo 'Menu';
echo ' &raquo; ';
echo '<a href="/'.IS_PORTAL.'/'.IS_LANG.'/prop_home/">Properly Rent/Maint.</a>';
echo ' &raquo; ';
echo '<a href="/'.IS_PORTAL.'/'.IS_LANG.'/prop_report_maint_payment/">Inquiries and Reports  - Maint. Payment Report</a>';
echo ' &raquo; ';
?>