<?php
// Portal share translate file for mult-languge support
// using _t($str) for translate on the fire

function _t($str){
	return($str);
}

?>