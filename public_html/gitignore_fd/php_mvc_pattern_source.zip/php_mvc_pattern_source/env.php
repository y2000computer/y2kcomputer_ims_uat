<?php

//Environment 
define('ENV', 'UAT');  //define('ENV', 'PROD');

//Debug setting
define('DEBUG_MODE', false);

//MySQL Database Connection setting
DEFINE('DB_HOST', 'localhost'); //sam notebook

DEFINE('DB_USERNAME', 'user_uat');
DEFINE('DB_PASSWORD', 'www.291073Ma!');  
DEFINE('DB_DBNAME', 'y2kcomputer_db_ims_uat');

//PDO_MysSQL connection string 
DEFINE('MYSQL_CONNECTION_STRING', ('mysql:host='.DB_HOST.';dbname='.DB_DBNAME));
DEFINE('DB_CONNECTION_STRING', MYSQL_CONNECTION_STRING);


//Portal Title
DEFINE('PORTAL_NAME', 'Y2K computer IMS System');
DEFINE('COPYRIGHT', 'Y2K Computer Solution Company');
DEFINE('DEFAULT_LANGUAGE', 'en-US');
DEFINE('APPLICATION_VERSION', '1.0');
DEFINE('DEFAULT_DATE_FORMAT', 'd/m/Y');


//Error log file setting 
define('DIR_FS_DOCS', __DIR__.'/log');
define('DIR_FS_STORE_LOG_USER', DIR_FS_DOCS . '/users/');


//Encryption 
define('SALT', 'REVAMP'); 

//Paging setting
define('SYSTEM_PAGE_ROW_LIMIT', '50');


//Email setting
$smtp['smtp_server'] = 'mail.hkber.com.hk';
$smtp['smtp_port'] = '25';
$smtp['outgoing_email_address'] = 'do_not_reply@hkber.com.hk';
$smtp['outgoing_email_address_password']  = 'do_not_reply.pwd';
$smtp['fr_email']  = 'do_not_reply@hkber.com.hk';
$smtp['from']  = 'do_not_reply';


//Photo Library setting
DEFINE('DIR_PHOTOS_UPLOAD_FOLDER', __DIR__.'/public_html/photos');
DEFINE('DIR_PHOTOS_PUBLIC_HTML', '/photos');
DEFINE('DIR_PUBLIC_UPLOAD', '../document');

DEFINE('DIR_DOCUMENT_UPLOAD_FOLDER', __DIR__.'/document');
DEFINE('DIR_PUBLIC_HTML', __DIR__.'/document');
 

//Article Front-end API
DEFINE('ALLOW_ORIGIN_DOMAIN','*');
DEFINE('API_DOMAIN','http://ims-uat.y2kcomputer.com/');


//Other
define('DIR_EXCEL_OUTPUT', '/../../../../../document/excel_output/');


?>

